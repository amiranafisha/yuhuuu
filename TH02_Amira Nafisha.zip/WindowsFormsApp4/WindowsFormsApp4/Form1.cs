﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        string pilihkata;
        public Form1()
        {
            InitializeComponent();
            panel2_Keyboard.Visible = false;
        }

        private void btn_Play_Click(object sender, EventArgs e)
        {
            List<string> kata = new List<string>();
            int kata1 = Convert.ToInt32(textBox1.Text.Length);
            int kata2 = Convert.ToInt32(textBox2.Text.Length);
            int kata3 = Convert.ToInt32(textBox3.Text.Length);
            int kata4 = Convert.ToInt32(textBox4.Text.Length);
            int kata5 = Convert.ToInt32(textBox5.Text.Length);

            if (kata1 != 5 || kata2 != 5 || kata3 != 5 || kata4 != 5 || kata5 != 5)
            {
                MessageBox.Show("There's still an error");
            }
            else if (textBox1.Text == textBox2.Text || textBox1.Text == textBox3.Text || textBox1.Text == textBox4.Text || textBox1.Text == textBox5.Text || textBox2.Text == textBox3.Text || textBox2.Text == textBox4.Text || textBox2.Text == textBox5.Text || textBox3.Text == textBox4.Text || textBox3.Text == textBox5.Text || textBox4.Text == textBox5.Text)
            {
                MessageBox.Show("There's still same words");
            }
            else
            {
                MessageBox.Show("Let's play !");
                panel1_Word.Visible = false;
                panel2_Keyboard.Visible = true;

                kata.Add(textBox1.Text);
                kata.Add(textBox2.Text);
                kata.Add(textBox3.Text);
                kata.Add(textBox4.Text);
                kata.Add(textBox5.Text);

                Random random = new Random();
                int tebak = random.Next(0, 5);

                pilihkata = kata[tebak].ToUpper();
                label1.Text = kata[tebak];
            }
        }

        public void Cek(char Alphabet)
        {
            int b = 1;
            for (int c = 0; c < 5; c++)
            {
                if (pilihkata[c] == Alphabet)
                {
                    b = c * 2;
                    lbTebak.Text = lbTebak.Text.Remove(b, 1);
                    lbTebak.Text = lbTebak.Text.Insert(b, Convert.ToString(Alphabet));
                }
            }
            string spasi = lbTebak.Text.Replace(" ", "");
            if (spasi == pilihkata)
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            Cek('Q');
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            Cek('W');
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            Cek('E');
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            Cek('R');
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            Cek('T');
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            Cek('Y');
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            Cek('U');
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            Cek('I');
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            Cek('O');
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            Cek('P');
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            Cek('A');
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            Cek('S');
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            Cek('D');
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            Cek('F');
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            Cek('G');
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            Cek('H');
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            Cek('J');
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            Cek('K');
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            Cek('L');
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            Cek('Z');
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            Cek('X');
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            Cek('C');
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            Cek('V');
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            Cek('B');
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            Cek('N');
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            Cek('M');
        }
    }
}
