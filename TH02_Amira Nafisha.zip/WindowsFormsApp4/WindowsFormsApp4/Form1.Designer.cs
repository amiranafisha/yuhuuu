﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Play = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lb_Word5 = new System.Windows.Forms.Label();
            this.lb_Word4 = new System.Windows.Forms.Label();
            this.lb_Word3 = new System.Windows.Forms.Label();
            this.lb_Word2 = new System.Windows.Forms.Label();
            this.lb_Word1 = new System.Windows.Forms.Label();
            this.lb_Jawaban = new System.Windows.Forms.Label();
            this.panel1_Word = new System.Windows.Forms.Panel();
            this.panel2_Keyboard = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lbTebak = new System.Windows.Forms.Label();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.panel1_Word.SuspendLayout();
            this.panel2_Keyboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Play
            // 
            this.btn_Play.Location = new System.Drawing.Point(93, 240);
            this.btn_Play.Name = "btn_Play";
            this.btn_Play.Size = new System.Drawing.Size(85, 30);
            this.btn_Play.TabIndex = 21;
            this.btn_Play.Text = "Play!";
            this.btn_Play.UseVisualStyleBackColor = true;
            this.btn_Play.Click += new System.EventHandler(this.btn_Play_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(72, 185);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(129, 26);
            this.textBox5.TabIndex = 20;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(72, 135);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(129, 26);
            this.textBox4.TabIndex = 19;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(72, 93);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(129, 26);
            this.textBox3.TabIndex = 18;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(72, 49);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(129, 26);
            this.textBox2.TabIndex = 17;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(72, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(129, 26);
            this.textBox1.TabIndex = 16;
            // 
            // lb_Word5
            // 
            this.lb_Word5.AutoSize = true;
            this.lb_Word5.Location = new System.Drawing.Point(2, 185);
            this.lb_Word5.Name = "lb_Word5";
            this.lb_Word5.Size = new System.Drawing.Size(64, 20);
            this.lb_Word5.TabIndex = 15;
            this.lb_Word5.Text = "Word 5:";
            // 
            // lb_Word4
            // 
            this.lb_Word4.AutoSize = true;
            this.lb_Word4.Location = new System.Drawing.Point(2, 141);
            this.lb_Word4.Name = "lb_Word4";
            this.lb_Word4.Size = new System.Drawing.Size(64, 20);
            this.lb_Word4.TabIndex = 14;
            this.lb_Word4.Text = "Word 4:";
            // 
            // lb_Word3
            // 
            this.lb_Word3.AutoSize = true;
            this.lb_Word3.Location = new System.Drawing.Point(2, 96);
            this.lb_Word3.Name = "lb_Word3";
            this.lb_Word3.Size = new System.Drawing.Size(64, 20);
            this.lb_Word3.TabIndex = 13;
            this.lb_Word3.Text = "Word 3:";
            // 
            // lb_Word2
            // 
            this.lb_Word2.AutoSize = true;
            this.lb_Word2.Location = new System.Drawing.Point(2, 52);
            this.lb_Word2.Name = "lb_Word2";
            this.lb_Word2.Size = new System.Drawing.Size(64, 20);
            this.lb_Word2.TabIndex = 12;
            this.lb_Word2.Text = "Word 2:";
            // 
            // lb_Word1
            // 
            this.lb_Word1.AutoSize = true;
            this.lb_Word1.Location = new System.Drawing.Point(2, 6);
            this.lb_Word1.Name = "lb_Word1";
            this.lb_Word1.Size = new System.Drawing.Size(64, 20);
            this.lb_Word1.TabIndex = 11;
            this.lb_Word1.Text = "Word 1:";
            // 
            // lb_Jawaban
            // 
            this.lb_Jawaban.AutoSize = true;
            this.lb_Jawaban.Location = new System.Drawing.Point(26, 157);
            this.lb_Jawaban.Name = "lb_Jawaban";
            this.lb_Jawaban.Size = new System.Drawing.Size(0, 20);
            this.lb_Jawaban.TabIndex = 63;
            // 
            // panel1_Word
            // 
            this.panel1_Word.Controls.Add(this.textBox4);
            this.panel1_Word.Controls.Add(this.textBox3);
            this.panel1_Word.Controls.Add(this.btn_Play);
            this.panel1_Word.Controls.Add(this.lb_Word1);
            this.panel1_Word.Controls.Add(this.textBox5);
            this.panel1_Word.Controls.Add(this.lb_Jawaban);
            this.panel1_Word.Controls.Add(this.textBox2);
            this.panel1_Word.Controls.Add(this.lb_Word2);
            this.panel1_Word.Controls.Add(this.textBox1);
            this.panel1_Word.Controls.Add(this.lb_Word5);
            this.panel1_Word.Controls.Add(this.lb_Word3);
            this.panel1_Word.Controls.Add(this.lb_Word4);
            this.panel1_Word.Location = new System.Drawing.Point(12, 12);
            this.panel1_Word.Name = "panel1_Word";
            this.panel1_Word.Size = new System.Drawing.Size(216, 287);
            this.panel1_Word.TabIndex = 64;
            // 
            // panel2_Keyboard
            // 
            this.panel2_Keyboard.Controls.Add(this.label1);
            this.panel2_Keyboard.Controls.Add(this.lbTebak);
            this.panel2_Keyboard.Controls.Add(this.btn_Z);
            this.panel2_Keyboard.Controls.Add(this.btn_X);
            this.panel2_Keyboard.Controls.Add(this.btn_C);
            this.panel2_Keyboard.Controls.Add(this.btn_V);
            this.panel2_Keyboard.Controls.Add(this.btn_N);
            this.panel2_Keyboard.Controls.Add(this.btn_M);
            this.panel2_Keyboard.Controls.Add(this.btn_B);
            this.panel2_Keyboard.Controls.Add(this.btn_A);
            this.panel2_Keyboard.Controls.Add(this.btn_S);
            this.panel2_Keyboard.Controls.Add(this.btn_D);
            this.panel2_Keyboard.Controls.Add(this.btn_F);
            this.panel2_Keyboard.Controls.Add(this.btn_G);
            this.panel2_Keyboard.Controls.Add(this.btn_H);
            this.panel2_Keyboard.Controls.Add(this.btn_J);
            this.panel2_Keyboard.Controls.Add(this.btn_K);
            this.panel2_Keyboard.Controls.Add(this.btn_L);
            this.panel2_Keyboard.Controls.Add(this.btn_Q);
            this.panel2_Keyboard.Controls.Add(this.btn_P);
            this.panel2_Keyboard.Controls.Add(this.btn_R);
            this.panel2_Keyboard.Controls.Add(this.btn_T);
            this.panel2_Keyboard.Controls.Add(this.btn_Y);
            this.panel2_Keyboard.Controls.Add(this.btn_U);
            this.panel2_Keyboard.Controls.Add(this.btn_E);
            this.panel2_Keyboard.Controls.Add(this.btn_I);
            this.panel2_Keyboard.Controls.Add(this.btn_O);
            this.panel2_Keyboard.Controls.Add(this.btn_W);
            this.panel2_Keyboard.Location = new System.Drawing.Point(234, 18);
            this.panel2_Keyboard.Name = "panel2_Keyboard";
            this.panel2_Keyboard.Size = new System.Drawing.Size(751, 360);
            this.panel2_Keyboard.TabIndex = 65;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(644, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 63;
            // 
            // lbTebak
            // 
            this.lbTebak.AutoSize = true;
            this.lbTebak.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTebak.Location = new System.Drawing.Point(250, 22);
            this.lbTebak.Name = "lbTebak";
            this.lbTebak.Size = new System.Drawing.Size(275, 73);
            this.lbTebak.TabIndex = 58;
            this.lbTebak.Text = "_ _ _ _ _";
            // 
            // btn_Z
            // 
            this.btn_Z.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Z.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Z.Location = new System.Drawing.Point(100, 261);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(49, 49);
            this.btn_Z.TabIndex = 57;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = false;
            this.btn_Z.Click += new System.EventHandler(this.btn_Z_Click);
            // 
            // btn_X
            // 
            this.btn_X.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_X.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_X.Location = new System.Drawing.Point(176, 261);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(49, 49);
            this.btn_X.TabIndex = 56;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = false;
            this.btn_X.Click += new System.EventHandler(this.btn_X_Click);
            // 
            // btn_C
            // 
            this.btn_C.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_C.Location = new System.Drawing.Point(249, 261);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(49, 49);
            this.btn_C.TabIndex = 55;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = false;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // btn_V
            // 
            this.btn_V.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_V.Location = new System.Drawing.Point(330, 261);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(49, 49);
            this.btn_V.TabIndex = 54;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = false;
            this.btn_V.Click += new System.EventHandler(this.btn_V_Click);
            // 
            // btn_N
            // 
            this.btn_N.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_N.Location = new System.Drawing.Point(486, 261);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(49, 49);
            this.btn_N.TabIndex = 53;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = false;
            this.btn_N.Click += new System.EventHandler(this.btn_N_Click);
            // 
            // btn_M
            // 
            this.btn_M.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_M.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_M.Location = new System.Drawing.Point(567, 261);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(49, 49);
            this.btn_M.TabIndex = 52;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = false;
            this.btn_M.Click += new System.EventHandler(this.btn_M_Click);
            // 
            // btn_B
            // 
            this.btn_B.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_B.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_B.Location = new System.Drawing.Point(408, 261);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(49, 49);
            this.btn_B.TabIndex = 51;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = false;
            this.btn_B.Click += new System.EventHandler(this.btn_B_Click);
            // 
            // btn_A
            // 
            this.btn_A.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_A.Location = new System.Drawing.Point(61, 194);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(49, 49);
            this.btn_A.TabIndex = 50;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = false;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // btn_S
            // 
            this.btn_S.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_S.Location = new System.Drawing.Point(136, 194);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(49, 49);
            this.btn_S.TabIndex = 49;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = false;
            this.btn_S.Click += new System.EventHandler(this.btn_S_Click);
            // 
            // btn_D
            // 
            this.btn_D.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_D.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_D.Location = new System.Drawing.Point(215, 194);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(49, 49);
            this.btn_D.TabIndex = 48;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = false;
            this.btn_D.Click += new System.EventHandler(this.btn_D_Click);
            // 
            // btn_F
            // 
            this.btn_F.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_F.Location = new System.Drawing.Point(293, 194);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(49, 49);
            this.btn_F.TabIndex = 47;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = false;
            this.btn_F.Click += new System.EventHandler(this.btn_F_Click);
            // 
            // btn_G
            // 
            this.btn_G.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_G.Location = new System.Drawing.Point(371, 194);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(49, 49);
            this.btn_G.TabIndex = 46;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = false;
            this.btn_G.Click += new System.EventHandler(this.btn_G_Click);
            // 
            // btn_H
            // 
            this.btn_H.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_H.Location = new System.Drawing.Point(449, 194);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(49, 49);
            this.btn_H.TabIndex = 45;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = false;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_J
            // 
            this.btn_J.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_J.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_J.Location = new System.Drawing.Point(524, 194);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(49, 49);
            this.btn_J.TabIndex = 44;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = false;
            this.btn_J.Click += new System.EventHandler(this.btn_J_Click);
            // 
            // btn_K
            // 
            this.btn_K.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_K.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_K.Location = new System.Drawing.Point(595, 194);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(49, 49);
            this.btn_K.TabIndex = 43;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = false;
            this.btn_K.Click += new System.EventHandler(this.btn_K_Click);
            // 
            // btn_L
            // 
            this.btn_L.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_L.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_L.Location = new System.Drawing.Point(665, 194);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(49, 49);
            this.btn_L.TabIndex = 42;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = false;
            this.btn_L.Click += new System.EventHandler(this.btn_L_Click);
            // 
            // btn_Q
            // 
            this.btn_Q.BackColor = System.Drawing.Color.DarkGray;
            this.btn_Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Q.Location = new System.Drawing.Point(23, 129);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(49, 49);
            this.btn_Q.TabIndex = 41;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = false;
            this.btn_Q.Click += new System.EventHandler(this.btn_Q_Click);
            // 
            // btn_P
            // 
            this.btn_P.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_P.Location = new System.Drawing.Point(699, 129);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(49, 49);
            this.btn_P.TabIndex = 40;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = false;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_R
            // 
            this.btn_R.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_R.Location = new System.Drawing.Point(249, 129);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(49, 49);
            this.btn_R.TabIndex = 39;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = false;
            this.btn_R.Click += new System.EventHandler(this.btn_R_Click);
            // 
            // btn_T
            // 
            this.btn_T.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_T.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_T.Location = new System.Drawing.Point(330, 129);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(49, 49);
            this.btn_T.TabIndex = 38;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = false;
            this.btn_T.Click += new System.EventHandler(this.btn_T_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Y.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Y.Location = new System.Drawing.Point(408, 129);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(49, 49);
            this.btn_Y.TabIndex = 37;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = false;
            this.btn_Y.Click += new System.EventHandler(this.btn_Y_Click);
            // 
            // btn_U
            // 
            this.btn_U.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_U.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_U.Location = new System.Drawing.Point(486, 129);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(49, 49);
            this.btn_U.TabIndex = 36;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = false;
            this.btn_U.Click += new System.EventHandler(this.btn_U_Click);
            // 
            // btn_E
            // 
            this.btn_E.BackColor = System.Drawing.Color.DarkGray;
            this.btn_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_E.Location = new System.Drawing.Point(176, 129);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(49, 49);
            this.btn_E.TabIndex = 35;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = false;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_I
            // 
            this.btn_I.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_I.Location = new System.Drawing.Point(556, 129);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(49, 49);
            this.btn_I.TabIndex = 34;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = false;
            this.btn_I.Click += new System.EventHandler(this.btn_I_Click);
            // 
            // btn_O
            // 
            this.btn_O.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_O.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_O.Location = new System.Drawing.Point(627, 129);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(49, 49);
            this.btn_O.TabIndex = 33;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = false;
            this.btn_O.Click += new System.EventHandler(this.btn_O_Click);
            // 
            // btn_W
            // 
            this.btn_W.BackColor = System.Drawing.Color.DarkGray;
            this.btn_W.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_W.Location = new System.Drawing.Point(100, 129);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(49, 49);
            this.btn_W.TabIndex = 32;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = false;
            this.btn_W.Click += new System.EventHandler(this.btn_W_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 450);
            this.Controls.Add(this.panel2_Keyboard);
            this.Controls.Add(this.panel1_Word);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1_Word.ResumeLayout(false);
            this.panel1_Word.PerformLayout();
            this.panel2_Keyboard.ResumeLayout(false);
            this.panel2_Keyboard.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Play;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lb_Word5;
        private System.Windows.Forms.Label lb_Word4;
        private System.Windows.Forms.Label lb_Word3;
        private System.Windows.Forms.Label lb_Word2;
        private System.Windows.Forms.Label lb_Word1;
        private System.Windows.Forms.Label lb_Jawaban;
        private System.Windows.Forms.Panel panel1_Word;
        private System.Windows.Forms.Panel panel2_Keyboard;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbTebak;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_W;
    }
}

